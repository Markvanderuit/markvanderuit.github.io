# Metameric

> Please note, this upload contains a Windows (X86) build of our spectral uplifting toolkit. We are planning to release the source code, but we're still tinkering with it for another project (and it really needs a good cleaning).

Here you'll find two components: Metameric, which is our toolkit for authoring compact spectral textures from RGB inputs, and a single-file C++ plugin for interfacing with [Mitsuba 3](https://github.com/mitsuba-renderer/mitsuba3). For details on the underlying method, check out our recent paper *Metameric: Spectral Uplifting via Controllable Color Constraints* ([journal page](https://doi.org/10.1145/3588432.3591565), [author page](https://markvanderuit.github.io/publications/2023-07-23-paper-metameric)).

## Platform support

Right now, it's a Windows build only. The code should work on Linux, but I haven't had the time to test it (if you want to try it on Linux, send me an angry email to remind me). Supported GPU vendors are NVIDIA (definitely works) and Intel HD (apparently works?!); AMD and Intel Arc are unknowns as I don't have those GPUs lying around.

## Toolkit usage

To get started, run the toolkit (`metameric.exe`). You'll be greeted by an empty view. Go to `file > new` to create a project, where you can add one or more images. If a single image is added, this is used as the base RGB input. If multiple images are added, constraints are fitted, which can take a minute. Note that constraint fitting in this way requires a large number of **interior samples**; it may fit poorly with a low sample count.

Once the project is loaded, you can add color systems in the **spectra editor** (bottom left). These are rendered in the **mapping viewer** (top left). Additional illuminants and sensor functions can be loaded from disk; these use the same file format used in mitsuba for SPD's. For example:

```
# wvl value
380 1
381 1.01
382 1.02
...
```

In the central **viewport**, you can rotate (CTRL or middle mouse hold) around the texture polytope. To select a single vertex, simply click its corresponding vertex. To select multiple vertices, drag the right mouse button. 

Once a vertex is selected, you can edit constraints on this vertex in the little overlay (viewport, top-left). For any given constraint, you can view and edit using its corresponding metamer mismatch volume when you press **edit**. When you edit constraints, the mapping viewer live re-renders to show the new uplifting.

Given one or more selected vertices, you can see what region of the texture you are affecting in the **weight viewer** (right).

When you are satisfied, you can save the project (`file > save as ...`). If you wish to use an uplifted texture in Mitsuba, export it to disk (`file > export`).

## Mitsuba plugin

The render plugin (`mitsuba/metameric_generalized.cpp`) needs to be added to the renderer for it to work, so you'll need to build Mitsuba 3. Refer to their [compilation guide](https://mitsuba.readthedocs.io/en/stable/src/developer_guide/compiling.html) for details on this process.

To add the plugin, simply add the source file to `src/textures` in mitsuba's source directory. Then, edit `src/textures/CMakeLists.txt` and add the following line to the list of plugins:

```
add_plugin(metameric_generalized metameric_generalized.cpp)
```

Once you recompile Mitsuba, the plugin should be added, and can be used as any other texture object in the renderer. An example object definition would be:

```
<texture type="metameric_generalized">
  <string name="filename" value="path/to/spectral_texture.met"/>
</texture>
```